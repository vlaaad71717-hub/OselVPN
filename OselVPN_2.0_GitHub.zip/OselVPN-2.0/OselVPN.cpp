// ============================================================================
//  OselVPN v2.0 — Win32-клиент VPN на ядре Xray (VLESS/REALITY/TLS/WS/gRPC)
//
//  Что нового в 2.0 (по сравнению с 1.x):
//   • Тёмный интерфейс в стиле Happ: большая круглая кнопка подключения
//   • Журнал ядра скрыт: открывается кнопкой «Журнал ядра» (и сам при ошибке)
//   • Пинг сервера: TCP (до сервера) и GET (реальный запрос через прокси)
//   • История серверов: быстрый выбор из списка, удаление, автосохранение
//   • Трей: закрытие сворачивает в трей, меню по правой кнопке
//   • Переключатели: системный прокси, автоподключение при запуске
//   • Надёжность: убийство зависшего xray.exe перед запуском, проверка порта,
//     авто-показ журнала при ошибке, контроль падения ядра во время VPN
//
//  Ядро xray.exe вшито в бинарник (COFF-блоб) и извлекается в %APPDATA%\OselVPN.
//  Сборка: см. build.sh  (zig c++ -target x86_64-windows-gnu ...)
// ============================================================================
#include <windows.h>
#include <wininet.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <tlhelp32.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>

#include "vless.h"   // ParseVless + BuildXrayConfig

// Вшитый payload ядра (COFF-объект xray_payload.o)
extern "C" const unsigned char _xray_payload_start[];
extern "C" const unsigned char _xray_payload_end[];

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "msimg32.lib")

// ---------------------------------------------------------------------------
// Идентификаторы
// ---------------------------------------------------------------------------
#define IDC_LINK        201
#define IDC_SERVERS     202
#define IDC_LOG         203
#define WM_APP_LOG      (WM_APP + 1)
#define WM_APP_PING     (WM_APP + 2)
#define WM_APP_TRAY     (WM_APP + 3)
#define ID_TIMER_ANIM   1
#define ID_TIMER_CHECK  2

static const int SOCKS_PORT = 10808;
static const int HTTP_PORT  = 10809;
static const wchar_t* APP_VER_TEXT = L"v2.0";
#define APP_VER L"v2.0"

#ifndef WM_CTLCOLORCOMBO
#define WM_CTLCOLORCOMBO 0x0138
#endif
#ifndef WM_CTLCOLORLISTBOX
#define WM_CTLCOLORLISTBOX 0x0134
#endif
#ifndef WM_CTLCOLOREDIT
#define WM_CTLCOLOREDIT 0x0133
#endif
#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lp) ((int)(short)LOWORD(lp))
#define GET_Y_LPARAM(lp) ((int)(short)HIWORD(lp))
#endif

// ---------------------------------------------------------------------------
// Состояние
// ---------------------------------------------------------------------------
enum State { ST_OFF, ST_CONNECTING, ST_ON, ST_ERROR };
static State  g_state = ST_OFF;
static std::wstring g_errorText;

static HWND g_hwnd, hLink, hServers, hLog;
static HFONT g_fTitle, g_fSub, g_fMain, g_fSmall, g_fBig, g_fLog, g_fStatus;

static HANDLE g_hXrayProc = NULL;
static HANDLE g_hLogThread = NULL;
static HANDLE g_logRead = NULL, g_logWrite = NULL;
static CRITICAL_SECTION g_logCS;
static std::string g_logPending;
static int   g_checkCount = 0;
static std::string g_dirA;
static float g_animT = 0;          // фаза анимации кольца
static ULONGLONG g_lastTick = 0;

static bool g_sysProxy   = true;   // включать системный прокси
static bool g_autoStart  = false;  // автоподключение при запуске
static bool g_logVisible = false;
static int  g_clientH    = 486;    // высота клиента (меняется с журналом)

static std::vector<std::pair<std::wstring, std::wstring>> g_servers; // (имя, ссылка)

// пинги: -1 не измеряли, -2 ошибка, -3 нет VPN, иначе мс
static volatile LONG g_tcpBusy = 0, g_getBusy = 0;
static int g_tcpPing = -1, g_getPing = -1;

static NOTIFYICONDATAW g_nid = {};

// ---------------------------------------------------------------------------
// Палитра
// ---------------------------------------------------------------------------
static const COLORREF C_BG_TOP    = RGB(16, 22, 36);
static const COLORREF C_BG_BOT    = RGB(26, 35, 52);
static const COLORREF C_PANEL     = RGB(11, 15, 24);
static const COLORREF C_BORDER    = RGB(42, 53, 80);
static const COLORREF C_TEXT      = RGB(230, 236, 255);
static const COLORREF C_TEXT_DIM  = RGB(140, 155, 190);
static const COLORREF C_ACCENT    = RGB(77, 141, 255);
static const COLORREF C_GREEN     = RGB(51, 209, 122);
static const COLORREF C_YELLOW    = RGB(255, 197, 61);
static const COLORREF C_RED       = RGB(255, 92, 92);
static const COLORREF C_RING_OFF  = RGB(58, 74, 107);
static const COLORREF C_BTN_FILL  = RGB(22, 32, 53);
static const COLORREF C_BTN_FILL2 = RGB(18, 48, 31);

// ---------------------------------------------------------------------------
// Утилиты
// ---------------------------------------------------------------------------
static std::string AppDir() {
    if (!g_dirA.empty()) return g_dirA;
    std::string dir = "C:\\OselVPN";
    const char* appdata = getenv("APPDATA");
    if (appdata) dir = std::string(appdata) + "\\OselVPN";
    CreateDirectoryA(dir.c_str(), NULL);
    g_dirA = dir;
    return dir;
}

static std::wstring AppDirW() {
    std::string d = AppDir();
    int n = MultiByteToWideChar(CP_UTF8, 0, d.c_str(), -1, NULL, 0);
    std::wstring w(n - 1, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, d.c_str(), -1, &w[0], n);
    return w;
}
static std::string WideToUtf8(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), NULL, 0, NULL, NULL);
    std::string s(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, NULL, NULL);
    return s;
}
static void InvalidateAll() { if (g_hwnd) InvalidateRect(g_hwnd, NULL, FALSE); }

// ---------------------------------------------------------------------------
// Настройки (settings.ini)
// ---------------------------------------------------------------------------
static std::string IniPath() { return AppDir() + "\\settings.ini"; }

static void LoadSettings() {
    g_sysProxy  = GetPrivateProfileIntA("ui", "sysproxy", 1, IniPath().c_str()) == 1;
    g_autoStart = GetPrivateProfileIntA("ui", "autostart", 0, IniPath().c_str()) == 1;
    g_logVisible= GetPrivateProfileIntA("ui", "logvisible", 0, IniPath().c_str()) == 1;
}
static void SaveSettings() {
    WritePrivateProfileStringA("ui", "sysproxy",  g_sysProxy  ? "1" : "0", IniPath().c_str());
    WritePrivateProfileStringA("ui", "autostart", g_autoStart ? "1" : "0", IniPath().c_str());
    WritePrivateProfileStringA("ui", "logvisible",g_logVisible? "1" : "0", IniPath().c_str());
}

// ---------------------------------------------------------------------------
// История серверов (servers.txt: "имя<TAB>ссылка")
// ---------------------------------------------------------------------------
static std::string ServersPath() { return AppDir() + "\\servers.txt"; }

static void LoadServers() {
    g_servers.clear();
    FILE* f = fopen(ServersPath().c_str(), "rb");
    if (!f) return;
    std::string all;
    char buf[4096]; size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) all.append(buf, n);
    fclose(f);
    size_t pos = 0;
    while (pos < all.size()) {
        size_t eol = all.find('\n', pos);
        std::string line = all.substr(pos, (eol == std::string::npos ? std::string::npos : eol - pos));
        pos = (eol == std::string::npos) ? all.size() : eol + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty()) continue;
        size_t tab = line.find('\t');
        if (tab == std::string::npos) continue;
        std::string name = line.substr(0, tab);
        std::string link = line.substr(tab + 1);
        g_servers.push_back({ WFromA(name), WFromA(link) });
    }
}
static void SaveServers() {
    FILE* f = fopen(ServersPath().c_str(), "wb");
    if (!f) return;
    for (auto& s : g_servers) {
        std::string line = WideToUtf8(s.first) + "\t" + WideToUtf8(s.second) + "\n";
        fwrite(line.data(), 1, line.size(), f);
    }
    fclose(f);
}
static void ReloadCombo() {
    SendMessageW(hServers, CB_RESETCONTENT, 0, 0);
    for (auto& s : g_servers)
        SendMessageW(hServers, CB_ADDSTRING, 0, (LPARAM)s.first.c_str());
}

// ---------------------------------------------------------------------------
// Трей
// ---------------------------------------------------------------------------
static void TrayAdd() {
    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = g_hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    g_nid.uCallbackMessage = WM_APP_TRAY;
    g_nid.hIcon = LoadIconW(NULL, (LPCWSTR)IDI_APPLICATION);
    lstrcpynW(g_nid.szTip, L"OselVPN " APP_VER, ARRAYSIZE(g_nid.szTip));
    Shell_NotifyIconW(NIM_ADD, &g_nid);
}
static void TrayUpdateTip(const wchar_t* tip) {
    lstrcpynW(g_nid.szTip, tip, ARRAYSIZE(g_nid.szTip));
    g_nid.uFlags = NIF_TIP;
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
}

// ---------------------------------------------------------------------------
// Системный прокси
// ---------------------------------------------------------------------------
static void SetSystemProxy(bool enable) {
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
        0, KEY_SET_VALUE, &hKey) != ERROR_SUCCESS) return;
    DWORD on = enable ? 1 : 0;
    RegSetValueExA(hKey, "ProxyEnable", 0, REG_DWORD, (const BYTE*)&on, sizeof(on));
    if (enable) {
        const char* server = "127.0.0.1:10809";
        const char* over   = "<local>";
        RegSetValueExA(hKey, "ProxyServer", 0, REG_SZ, (const BYTE*)server, (DWORD)strlen(server) + 1);
        RegSetValueExA(hKey, "ProxyOverride", 0, REG_SZ, (const BYTE*)over, (DWORD)strlen(over) + 1);
    }
    RegCloseKey(hKey);
    InternetSetOptionA(NULL, INTERNET_OPTION_SETTINGS_CHANGED, NULL, 0);
    InternetSetOptionA(NULL, INTERNET_OPTION_REFRESH, NULL, 0);
}

// ---------------------------------------------------------------------------
// Журнал ядра
// ---------------------------------------------------------------------------
static void AppendLogLockedChunk() {
    std::string chunk;
    EnterCriticalSection(&g_logCS);
    chunk.swap(g_logPending);
    LeaveCriticalSection(&g_logCS);
    if (chunk.empty() || !hLog) return;
    std::wstring w(chunk.begin(), chunk.end());
    int len = GetWindowTextLengthW(hLog);
    if (len > 250000) { SetWindowTextW(hLog, L""); len = 0; } // не даём журналу расти бесконечно
    SendMessageW(hLog, EM_SETSEL, len, len);
    SendMessageW(hLog, EM_REPLACESEL, FALSE, (LPARAM)w.c_str());
}
static DWORD WINAPI LogThreadProc(LPVOID) {
    char buf[4096]; DWORD n = 0;
    while (g_logRead && ReadFile(g_logRead, buf, sizeof(buf), &n, NULL) && n > 0) {
        EnterCriticalSection(&g_logCS);
        g_logPending.append(buf, n);
        LeaveCriticalSection(&g_logCS);
        if (g_hwnd) PostMessageW(g_hwnd, WM_APP_LOG, 0, 0);
    }
    return 0;
}
static void ShowLog(bool show) {
    g_logVisible = show;
    ShowWindow(hLog, show ? SW_SHOWNOACTIVATE : SW_HIDE);
    g_clientH = show ? 668 : 486;
    RECT rc; GetWindowRect(g_hwnd, &rc);
    SetWindowPos(g_hwnd, NULL, rc.left, rc.top, 720 + 16, g_clientH + 46,
                 SWP_NOZORDER | SWP_NOMOVE);
    SaveSettings();
    InvalidateAll();
}

// ---------------------------------------------------------------------------
// Xray: извлечение, устаревший процесс, запуск/остановка
// ---------------------------------------------------------------------------
static std::string ExtractXray() {
    std::string dst = AppDir() + "\\xray.exe";
    size_t payloadSize = (size_t)(_xray_payload_end - _xray_payload_start);
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (payloadSize > 0 && GetFileAttributesExA(dst.c_str(), GetFileExInfoStandard, &fa)) {
        ULARGE_INTEGER sz; sz.HighPart = fa.nFileSizeHigh; sz.LowPart = fa.nFileSizeLow;
        if (sz.QuadPart == payloadSize) return dst;
    }
    FILE* f = fopen(dst.c_str(), "wb");
    if (!f) return "";
    fwrite(_xray_payload_start, 1, payloadSize, f);
    fclose(f);
    return dst;
}

// Убить xray.exe, запущенный именно из нашей папки (завис после сбоя)
static void KillStaleXray() {
    std::string ourXray = AppDir() + "\\xray.exe";
    for (auto& c : ourXray) if (c == '/') c = '\\';
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return;
    PROCESSENTRY32W pe = {}; pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, L"xray.exe") != 0) continue;
            HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
            if (!p) continue;
            wchar_t path[MAX_PATH * 2] = L"";
            DWORD sz = ARRAYSIZE(path);
            if (QueryFullProcessImageNameW(p, 0, path, &sz)) {
                std::wstring wpath = path;
                for (auto& c : wpath) if (c == '/') c = '\\';
                // сравниваем без учёта регистра
                std::wstring a = WFromA(ourXray), b = wpath;
                for (auto& c : a) c = towlower(c);
                for (auto& c : b) c = towlower(c);
                if (a == b) TerminateProcess(p, 0);
            }
            CloseHandle(p);
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
}

static void StopXray() {
    if (g_hXrayProc) {
        TerminateProcess(g_hXrayProc, 0);
        CloseHandle(g_hXrayProc);
        g_hXrayProc = NULL;
    }
    if (g_logRead) { CloseHandle(g_logRead); g_logRead = NULL; }
    if (g_logWrite) { CloseHandle(g_logWrite); g_logWrite = NULL; }
    if (g_sysProxy) SetSystemProxy(false);
    TrayUpdateTip(L"OselVPN — отключено");
}

static bool CheckAlive() {
    if (!g_hXrayProc) return false;
    if (WaitForSingleObject(g_hXrayProc, 0) == WAIT_OBJECT_0) return false;
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
    SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCKET) return false;
    sockaddr_in a = {};
    a.sin_family = AF_INET;
    a.sin_port = htons(SOCKS_PORT);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    bool ok = (connect(s, (sockaddr*)&a, sizeof(a)) == 0);
    closesocket(s);
    return ok;
}

// ---------------------------------------------------------------------------
// Подключение / отключение
// ---------------------------------------------------------------------------
static void SetState(State st, const wchar_t* err = NULL) {
    g_state = st;
    g_errorText = err ? err : L"";
    if (st == ST_ERROR && !g_logVisible) ShowLog(true);   // при ошибке показываем журнал
    if (g_hwnd) {
        wchar_t tip[128];
        if (st == ST_ON) lstrcpynW(tip, L"OselVPN — подключено", 128);
        else if (st == ST_CONNECTING) lstrcpynW(tip, L"OselVPN — подключение…", 128);
        else if (st == ST_ERROR) lstrcpynW(tip, L"OselVPN — ошибка", 128);
        else lstrcpynW(tip, L"OselVPN — отключено", 128);
        TrayUpdateTip(tip);
    }
    InvalidateAll();
}

static std::wstring GetLinkText() {
    int len = GetWindowTextLengthW(hLink);
    std::wstring link(len, L'\0');
    if (len) GetWindowTextW(hLink, &link[0], len + 1);
    while (!link.empty() && (link.back() == L'\n' || link.back() == L'\r' || link.back() == L' ')) link.pop_back();
    return link;
}

static void AddServerToHistory(const VlessConfig& c, const std::wstring& link) {
    std::wstring name = c.name.empty() ? (c.host + L":" + c.port) : c.name;
    for (auto& s : g_servers) if (s.second == link) { s.first = name; SaveServers(); ReloadCombo(); return; }
    g_servers.push_back({ name, link });
    SaveServers();
    ReloadCombo();
}

static void DoConnect() {
    if (g_state == ST_CONNECTING) return;
    std::wstring link = GetLinkText();

    VlessConfig c = ParseVless(link);
    if (!c.ok) {
        SetState(ST_ERROR, (L"Ошибка ссылки: " + c.error).c_str());
        return;
    }

    SetState(ST_CONNECTING);
    SetWindowTextW(hLog, L"");

    // сохранить ссылку
    {
        std::string lf = AppDir() + "\\last_link.txt";
        FILE* f = fopen(lf.c_str(), "wb");
        if (f) { std::string u8 = WideToUtf8(link); fwrite(u8.data(), 1, u8.size(), f); fclose(f); }
    }

    KillStaleXray();

    std::string xrayPath = ExtractXray();
    if (xrayPath.empty()) { SetState(ST_ERROR, L"Не удалось извлечь xray.exe из бинарника"); return; }

    std::string cfgPath = AppDir() + "\\config.json";
    {
        std::string cfg = BuildXrayConfig(c, SOCKS_PORT, HTTP_PORT);
        FILE* f = fopen(cfgPath.c_str(), "wb");
        if (!f) { SetState(ST_ERROR, L"Ошибка записи config.json"); return; }
        fwrite(cfg.data(), 1, cfg.size(), f);
        fclose(f);
    }

    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&g_logRead, &g_logWrite, &sa, 0)) { SetState(ST_ERROR, L"Ошибка CreatePipe"); return; }
    SetHandleInformation(g_logRead, HANDLE_FLAG_INHERIT, 0);

    std::string cmd = "\"" + xrayPath + "\" run -c \"" + cfgPath + "\"";
    STARTUPINFOA si = {};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = si.hStdError = g_logWrite;
    PROCESS_INFORMATION pi = {};
    BOOL ok = CreateProcessA(NULL, &cmd[0], NULL, NULL, TRUE,
                             CREATE_NO_WINDOW, NULL, g_dirA.c_str(), &si, &pi);
    CloseHandle(g_logWrite); g_logWrite = NULL;
    if (!ok) {
        AppendLogLockedChunk();
        SetState(ST_ERROR, L"Не удалось запустить ядро Xray");
        CloseHandle(g_logRead); g_logRead = NULL;
        return;
    }
    CloseHandle(pi.hThread);
    g_hXrayProc = pi.hProcess;
    g_checkCount = 0;
    if (g_logRead) g_hLogThread = CreateThread(NULL, 0, LogThreadProc, NULL, 0, NULL);
    SetTimer(g_hwnd, ID_TIMER_CHECK, 900, NULL);
}

static void OnCheckTimer() {
    KillTimer(g_hwnd, ID_TIMER_CHECK);
    if (!g_hXrayProc) return;
    if (WaitForSingleObject(g_hXrayProc, 0) == WAIT_OBJECT_0) {
        StopXray();
        AppendLogLockedChunk();
        SetState(ST_ERROR, L"Ядро завершилось — проверь ссылку в журнале");
        return;
    }
    if (CheckAlive()) {
        if (g_sysProxy) SetSystemProxy(true);
        SetState(ST_ON);
        // автопинг TCP после подключения
        PostMessageW(g_hwnd, WM_COMMAND, 901, 0);
        return;
    }
    if (++g_checkCount < 5) { SetTimer(g_hwnd, ID_TIMER_CHECK, 900, NULL); return; }
    StopXray();
    AppendLogLockedChunk();
    SetState(ST_ERROR, L"Сервер не отвечает (порт закрыт / неверная ссылка)");
}

static void DoDisconnect() {
    KillTimer(g_hwnd, ID_TIMER_CHECK);
    StopXray();
    SetState(ST_OFF);
}

// ---------------------------------------------------------------------------
// Пинг
// ---------------------------------------------------------------------------
struct PingJob { std::string host; int port; };

static DWORD WINAPI TcpPingThread(LPVOID p) {
    PingJob* job = (PingJob*)p;
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);

    addrinfo hints = {};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* res = NULL;
    int ms = -2;
    if (getaddrinfo(job->host.c_str(), std::to_string(job->port).c_str(), &hints, &res) == 0 && res) {
        LARGE_INTEGER f, t0, t1;
        QueryPerformanceFrequency(&f);
        QueryPerformanceCounter(&t0);
        SOCKET s = socket(res->ai_family, SOCK_STREAM, 0);
        if (s != INVALID_SOCKET) {
            u_long nb = 1; ioctlsocket(s, FIONBIO, &nb);
            connect(s, res->ai_addr, (int)res->ai_addrlen);
            fd_set wset; FD_ZERO(&wset); FD_SET(s, &wset);
            timeval tv = { 3, 0 };
            if (select(0, NULL, &wset, NULL, &tv) > 0) {
                QueryPerformanceCounter(&t1);
                ms = (int)((t1.QuadPart - t0.QuadPart) * 1000 / f.QuadPart);
            }
            closesocket(s);
        }
        freeaddrinfo(res);
    }
    delete job;
    PostMessageW(g_hwnd, WM_APP_PING, 0, (LPARAM)ms);
    InterlockedExchange(&g_tcpBusy, 0);
    return 0;
}

static DWORD WINAPI GetPingThread(LPVOID) {
    // Реальный запрос через локальный HTTP-прокси: http://www.gstatic.com/generate_204
    int ms = -2;
    HINTERNET hOpen = InternetOpenA("OselVPN/2.0", INTERNET_OPEN_TYPE_PROXY,
                                    "127.0.0.1:10809", NULL, 0);
    if (hOpen) {
        DWORD tConnect = 5000, tRecv = 5000, tSend = 5000;
        InternetSetOptionA(hOpen, INTERNET_OPTION_CONNECT_TIMEOUT, &tConnect, sizeof(DWORD));
        InternetSetOptionA(hOpen, INTERNET_OPTION_RECEIVE_TIMEOUT, &tRecv, sizeof(DWORD));
        InternetSetOptionA(hOpen, INTERNET_OPTION_SEND_TIMEOUT, &tSend, sizeof(DWORD));
        LARGE_INTEGER f, t0, t1;
        QueryPerformanceFrequency(&f);
        QueryPerformanceCounter(&t0);
        HINTERNET hUrl = InternetOpenUrlA(hOpen, "http://www.gstatic.com/generate_204",
                                          NULL, 0, INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_RELOAD, 0);
        if (hUrl) {
            char buf[512]; DWORD rd = 0;
            BOOL ok;
            do { ok = InternetReadFile(hUrl, buf, sizeof(buf), &rd); } while (ok && rd > 0);
            InternetCloseHandle(hUrl);
            QueryPerformanceCounter(&t1);
            ms = (int)((t1.QuadPart - t0.QuadPart) * 1000 / f.QuadPart);
        }
        InternetCloseHandle(hOpen);
    }
    PostMessageW(g_hwnd, WM_APP_PING, 1, (LPARAM)ms);
    InterlockedExchange(&g_getBusy, 0);
    return 0;
}

static void StartTcpPing() {
    if (InterlockedCompareExchange(&g_tcpBusy, 1, 0) != 0) return;
    VlessConfig c = ParseVless(GetLinkText());
    if (!c.ok) { g_tcpPing = -2; InvalidateAll(); InterlockedExchange(&g_tcpBusy, 0); return; }
    PingJob* job = new PingJob{ WideToUtf8(c.host), _wtoi(c.port.c_str()) };
    if (!job->port) job->port = 443;
    g_tcpPing = -1;
    CloseHandle(CreateThread(NULL, 0, TcpPingThread, job, 0, NULL));
    InvalidateAll();
}

static void StartGetPing() {
    if (g_state != ST_ON) { g_getPing = -3; InvalidateAll(); return; }
    if (InterlockedCompareExchange(&g_getBusy, 1, 0) != 0) return;
    g_getPing = -1;
    CloseHandle(CreateThread(NULL, 0, GetPingThread, NULL, 0, NULL));
    InvalidateAll();
}

// ---------------------------------------------------------------------------
// Рисование
// ---------------------------------------------------------------------------
static void FillGradient(HDC dc, const RECT& rc, COLORREF top, COLORREF bottom) {
    TRIVERTEX v[2] = {
        { rc.left,  rc.top,    (COLOR16)(GetRValue(top) << 8), (COLOR16)(GetGValue(top) << 8), (COLOR16)(GetBValue(top) << 8), 255 },
        { rc.right, rc.bottom, (COLOR16)(GetRValue(bottom) << 8), (COLOR16)(GetGValue(bottom) << 8), (COLOR16)(GetBValue(bottom) << 8), 255 },
    };
    GRADIENT_RECT g = { 0, 1 };
    GradientFill(dc, v, 2, &g, 1, GRADIENT_FILL_RECT_V);
}
static void DrawTextW2(HDC dc, const std::wstring& s, RECT rc, HFONT f, COLORREF col, UINT flags) {
    HFONT of = (HFONT)SelectObject(dc, f);
    SetTextColor(dc, col);
    DrawTextW(dc, s.c_str(), -1, &rc, flags | DT_SINGLELINE | DT_NOPREFIX);
    SelectObject(dc, of);
}
static void DrawRoundRect(HDC dc, RECT rc, int rad, COLORREF fill, COLORREF border) {
    HBRUSH b = CreateSolidBrush(fill);
    HPEN p = border ? CreatePen(PS_SOLID, 1, border) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, p);
    RoundRect(dc, rc.left, rc.top, rc.right, rc.bottom, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(b);
    if (border) DeleteObject(p);
}

// геометрия (клиент 720 x g_clientH)
static const int CW = 720;
static POINT g_btnC = { 360, 268 };
static const int BTN_R = 78;
static RECT g_rcTcp   = { 236, 392, 344, 424 };
static RECT g_rcGet   = { 356, 392, 464, 424 };
static RECT g_rcPaste = { 592, 100, 696, 130 };
static RECT g_rcDel   = { 456, 142, 546, 168 };
static RECT g_rcTog1  = { 24, 440, 244, 466 };
static RECT g_rcTog2  = { 254, 440, 434, 466 };
static RECT g_rcLogT  = { 540, 440, 700, 466 };

static bool InRect(RECT r, POINT p) { return p.x >= r.left && p.x < r.right && p.y >= r.top && p.y < r.bottom; }

static void DrawRing(HDC dc, POINT c, int r, int w, COLORREF col) {
    HPEN p = CreatePen(PS_SOLID, w, col);
    HGDIOBJ op = SelectObject(dc, p);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH));
    Ellipse(dc, c.x - r, c.y - r, c.x + r, c.y + r);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(p);
}
static void DrawArc(HDC dc, POINT c, int r, int w, COLORREF col, float frac, float rot) {
    HPEN p = CreatePen(PS_SOLID, w, col);
    HGDIOBJ op = SelectObject(dc, p);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH));
    int start = (int)(rot * 360);
    int sweep = (int)(frac * 360);
    Arc(dc, c.x - r, c.y - r, c.x + r, c.y + r,
        c.x + (int)(r * cos((start + sweep) * 3.14159f / 180)),
        c.y + (int)(r * sin((start + sweep) * 3.14159f / 180)),
        c.x + (int)(r * cos(start * 3.14159f / 180)),
        c.y + (int)(r * sin(start * 3.14159f / 180)));
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(p);
}

static void Paint(HDC dc) {
    RECT rcFull = { 0, 0, CW, g_clientH };
    FillGradient(dc, rcFull, C_BG_TOP, C_BG_BOT);
    SetBkMode(dc, TRANSPARENT);

    // заголовок
    DrawTextW2(dc, L"OselVPN", { 24, 12, 400, 52 }, g_fTitle, C_TEXT, DT_LEFT);
    DrawTextW2(dc, APP_VER, { 640, 16, 700, 40 }, g_fSmall, C_TEXT_DIM, DT_RIGHT);
    DrawTextW2(dc, L"Xray core  •  VLESS / REALITY / TLS / WS / gRPC", { 24, 50, 700, 72 }, g_fSmall, C_TEXT_DIM, DT_LEFT);

    // ссылка
    DrawTextW2(dc, L"Ссылка VLESS:", { 24, 78, 400, 98 }, g_fSmall, C_TEXT_DIM, DT_LEFT);
    // (EDIT рисуется системой; рамку рисуем здесь)
    RECT rcEdit = { 23, 99, 585, 131 };
    DrawRoundRect(dc, rcEdit, 6, C_PANEL, C_BORDER);
    // кнопка «Вставить»
    DrawRoundRect(dc, g_rcPaste, 6, g_rcPaste.right ? RGB(30, 42, 66) : C_PANEL, C_BORDER);
    DrawTextW2(dc, L"Вставить", g_rcPaste, g_fSmall, C_TEXT, DT_CENTER | DT_VCENTER);

    // серверы
    DrawTextW2(dc, L"История серверов:", { 24, 138, 300, 158 }, g_fSmall, C_TEXT_DIM, DT_LEFT);
    DrawRoundRect(dc, g_rcDel, 6, RGB(30, 42, 66), C_BORDER);
    DrawTextW2(dc, L"Удалить", g_rcDel, g_fSmall, C_TEXT_DIM, DT_CENTER | DT_VCENTER);

    // большая круглая кнопка
    POINT c = g_btnC;
    if (g_state == ST_ON) {
        // мягкое «свечение»: 3 расширяющихся кольца с затуханием
        for (int i = 1; i <= 3; i++) {
            COLORREF glow = RGB(18 + 10 * i, 48 + 18 * i, 31 + 12 * i);
            DrawRing(dc, c, BTN_R + i * 4, 3, glow);
        }
    }
    COLORREF ring = (g_state == ST_ON) ? C_GREEN : (g_state == ST_ERROR ? C_RED : C_RING_OFF);
    COLORREF fill = (g_state == ST_ON) ? C_BTN_FILL2 : C_BTN_FILL;
    HBRUSH b = CreateSolidBrush(fill);
    HPEN p = CreatePen(PS_SOLID, 2, ring);
    HGDIOBJ ob = SelectObject(dc, b), op = SelectObject(dc, p);
    Ellipse(dc, c.x - BTN_R, c.y - BTN_R, c.x + BTN_R, c.y + BTN_R);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(b); DeleteObject(p);

    if (g_state == ST_CONNECTING) {
        DrawRing(dc, c, BTN_R, 5, C_RING_OFF);
        float frac = 0.22f + 0.10f * sinf(g_animT * 2.1f);
        DrawArc(dc, c, BTN_R, 6, C_ACCENT, frac, g_animT * 260);
    } else {
        DrawRing(dc, c, BTN_R, 5, ring);
        if (g_state == ST_ON) {
            float pulse = 0.5f + 0.5f * sinf(g_animT * 2.4f);
            int rr = 10 + (int)(2 * pulse);
            HBRUSH gb = CreateSolidBrush(C_GREEN);
            HGDIOBJ og = SelectObject(dc, gb);
            Ellipse(dc, c.x + BTN_R / 2 - rr, c.y - BTN_R / 2 - rr, c.x + BTN_R / 2 + rr, c.y - BTN_R / 2 + rr);
            SelectObject(dc, og);
            DeleteObject(gb);
        }
    }
    const wchar_t* bigLabel =
        (g_state == ST_ON)          ? L"ОТКЛЮЧИТЬ"   :
        (g_state == ST_CONNECTING)  ? L"СТОП"         : L"ПОДКЛЮЧИТЬ";
    DrawTextW2(dc, bigLabel, { c.x - BTN_R, c.y - 26, c.x + BTN_R, c.y + 26 }, g_fBig, C_TEXT, DT_CENTER | DT_VCENTER);
    if (g_state == ST_OFF || g_state == ST_ERROR)
        DrawTextW2(dc, L"нажми на круг", { c.x - BTN_R, c.y + 26, c.x + BTN_R, c.y + 52 }, g_fSmall, C_TEXT_DIM, DT_CENTER);

    // статус
    COLORREF dotCol = (g_state == ST_ON) ? C_GREEN : (g_state == ST_CONNECTING ? C_YELLOW :
                      (g_state == ST_ERROR ? C_RED : C_TEXT_DIM));
    std::wstring stText =
        (g_state == ST_ON)          ? L"Подключено  •  прокси 127.0.0.1:10809 (HTTP) / 10808 (SOCKS)" :
        (g_state == ST_CONNECTING)  ? L"Подключение…" :
        (g_state == ST_ERROR)       ? g_errorText : L"Отключено";
    {
        int dotX = 250;
        HBRUSH db = CreateSolidBrush(dotCol);
        HGDIOBJ og = SelectObject(dc, db);
        Ellipse(dc, dotX - 5, 362, dotX + 5, 372);
        SelectObject(dc, og);
        DeleteObject(db);
        DrawTextW2(dc, stText, { dotX + 14, 352, CW - 24, 384 }, g_fStatus, C_TEXT, DT_LEFT | DT_VCENTER);
    }

    // пинг
    bool tBusy = g_tcpBusy != 0, gBusy = g_getBusy != 0;
    DrawRoundRect(dc, g_rcTcp, 6, tBusy ? RGB(30, 42, 66) : C_PANEL, C_BORDER);
    DrawTextW2(dc, tBusy ? L"TCP…" : L"Пинг TCP", g_rcTcp, g_fSmall, C_TEXT, DT_CENTER | DT_VCENTER);
    DrawRoundRect(dc, g_rcGet, 6, gBusy ? RGB(30, 42, 66) : C_PANEL, C_BORDER);
    DrawTextW2(dc, gBusy ? L"GET…" : L"Пинг GET", g_rcGet, g_fSmall, C_TEXT, DT_CENTER | DT_VCENTER);

    wchar_t res[128];
    auto fmt = [&](int v, const wchar_t* wait, const wchar_t* fail, const wchar_t* novpn) -> std::wstring {
        if (v == -1) return wait;
        if (v == -2) return fail;
        if (v == -3) return novpn;
        wchar_t b[32]; swprintf(b, 32, L"%d мс", v); return b;
    };
    std::wstring tcpS = fmt(g_tcpPing, L"—", L"ошибка", L"—");
    std::wstring getS = fmt(g_getPing, L"—", L"ошибка", L"нет VPN");
    swprintf(res, 128, L"TCP: %s   •   GET: %s", tcpS.c_str(), getS.c_str());
    DrawTextW2(dc, res, { 476, 392, CW - 24, 424 }, g_fSmall, C_TEXT_DIM, DT_LEFT | DT_VCENTER);

    // переключатели
    auto drawToggle = [&](RECT rc, const wchar_t* label, bool on) {
        DrawTextW2(dc, label, { rc.left, rc.top, rc.left + 150, rc.bottom }, g_fSmall, C_TEXT, DT_LEFT | DT_VCENTER);
        RECT sw = { rc.right - 44, rc.top + 4, rc.right, rc.bottom - 4 };
        DrawRoundRect(dc, sw, 9, on ? C_ACCENT : RGB(52, 64, 92), 0);
        if (on) { RECT k = { sw.right - 20, sw.top + 2, sw.right - 2, sw.bottom - 2 }; DrawRoundRect(dc, k, 8, C_TEXT, 0); }
        else    { RECT k = { sw.left + 2,  sw.top + 2, sw.left + 20, sw.bottom - 2 }; DrawRoundRect(dc, k, 8, RGB(120, 132, 160), 0); }
    };
    drawToggle(g_rcTog1, L"Системный прокси", g_sysProxy);
    drawToggle(g_rcTog2, L"Автозапуск", g_autoStart);

    // журнал-переключатель
    DrawTextW2(dc, g_logVisible ? L"Журнал ядра ▴" : L"Журнал ядра ▸",
               g_rcLogT, g_fSmall, C_ACCENT, DT_RIGHT | DT_VCENTER);

    // подсказка
    DrawTextW2(dc, L"Порты: SOCKS5 10808, HTTP 10809. Пинг GET — реальный запрос через прокси.",
               { 24, 468, 560, 486 }, g_fSmall, RGB(100, 112, 142), DT_LEFT);
}

// ---------------------------------------------------------------------------
// Окно
// ---------------------------------------------------------------------------
static void ToggleConnect() {
    if (g_state == ST_CONNECTING) { DoDisconnect(); KillTimer(g_hwnd, ID_TIMER_CHECK); }
    else if (g_state == ST_ON) DoDisconnect();
    else DoConnect();
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        g_fTitle  = CreateFontW(30, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_fBig    = CreateFontW(21, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_fMain   = CreateFontW(17, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_fSmall  = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_fStatus = CreateFontW(15, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
        g_fLog    = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Consolas");

        // EDIT ссылки
        hLink = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                 WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                 24, 100, 560, 30, hwnd, (HMENU)IDC_LINK, NULL, NULL);
        SendMessageW(hLink, WM_SETFONT, (WPARAM)g_fMain, TRUE);

        // список серверов
        hServers = CreateWindowW(L"COMBOBOX", L"",
                 WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_TABSTOP,
                 24, 142, 420, 300, hwnd, (HMENU)IDC_SERVERS, NULL, NULL);
        SendMessageW(hServers, WM_SETFONT, (WPARAM)g_fSmall, TRUE);

        // журнал (скрыт)
        hLog = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                 WS_CHILD | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY,
                 24, 482, 672, 170, hwnd, (HMENU)IDC_LOG, NULL, NULL);
        SendMessageW(hLog, WM_SETFONT, (WPARAM)g_fLog, TRUE);

        LoadSettings();
        LoadServers();
        ReloadCombo();

        // последняя ссылка
        {
            std::string lf = AppDir() + "\\last_link.txt";
            FILE* f = fopen(lf.c_str(), "rb");
            if (f) {
                std::string u8; char buf[4096]; size_t n;
                while ((n = fread(buf, 1, sizeof(buf), f)) > 0) u8.append(buf, n);
                fclose(f);
                std::wstring w = WFromA(u8);
                SetWindowTextW(hLink, w.c_str());
            }
        }

        TrayAdd();
        KillStaleXray(); // зависший процесс от прошлого запуска мешал портам

        if (g_logVisible) { g_clientH = 486; ShowLog(true); }

        SetTimer(hwnd, ID_TIMER_ANIM, 33, NULL);

        if (g_autoStart && !GetLinkText().empty())
            PostMessageW(hwnd, WM_COMMAND, 900, 0); // авто-подключение
        break;
    }

    case WM_CTLCOLOREDIT: { // тёмный журнал и edit списка
        HDC dc = (HDC)wParam;
        SetTextColor(dc, C_TEXT);
        SetBkColor(dc, C_PANEL);
        static HBRUSH br = CreateSolidBrush(C_PANEL);
        return (LRESULT)br;
    }
    case WM_CTLCOLORLISTBOX:
    case WM_CTLCOLORCOMBO: {
        HDC dc = (HDC)wParam;
        SetTextColor(dc, C_TEXT);
        SetBkColor(dc, C_PANEL);
        static HBRUSH br2 = CreateSolidBrush(C_PANEL);
        return (LRESULT)br2;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        if (id == 900) { DoConnect(); return 0; }              // авто/программное подключение
        if (id == 901) { StartTcpPing(); return 0; }           // автопинг после подключения
        if (id == IDC_SERVERS) {
            if (HIWORD(wParam) == CBN_SELCHANGE) {
                int sel = (int)SendMessageW(hServers, CB_GETCURSEL, 0, 0);
                if (sel >= 0 && sel < (int)g_servers.size())
                    SetWindowTextW(hLink, g_servers[sel].second.c_str());
            }
        }
        return 0;
    }

    case WM_TIMER:
        if (wParam == ID_TIMER_ANIM) {
            ULONGLONG now = GetTickCount64();
            float dt = (now - g_lastTick) / 1000.0f;
            g_lastTick = now;
            if (g_state == ST_CONNECTING || g_state == ST_ON) {
                g_animT += dt;
                // контроль: ядро не умерло?
                if (g_state == ST_ON && g_hXrayProc &&
                    WaitForSingleObject(g_hXrayProc, 0) == WAIT_OBJECT_0) {
                    StopXray();
                    SetState(ST_ERROR, L"Ядро завершилось — смотри журнал");
                }
                InvalidateAll();
            }
        } else if (wParam == ID_TIMER_CHECK) OnCheckTimer();
        break;

    case WM_APP_LOG:
        AppendLogLockedChunk();
        return 0;

    case WM_APP_PING:
        if (wParam == 0) g_tcpPing = (int)lParam;
        else             g_getPing = (int)lParam;
        InvalidateAll();
        return 0;

    case WM_LBUTTONDOWN: {
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        // большая кнопка
        int dx = pt.x - g_btnC.x, dy = pt.y - g_btnC.y;
        if (dx * dx + dy * dy <= BTN_R * BTN_R) { ToggleConnect(); return 0; }
        if (InRect(g_rcTcp, pt))  { StartTcpPing(); return 0; }
        if (InRect(g_rcGet, pt))  { StartGetPing(); return 0; }
        if (InRect(g_rcPaste, pt)) {
            if (OpenClipboard(hwnd)) {
                HANDLE h = GetClipboardData(CF_UNICODETEXT);
                if (h) { const wchar_t* t = (const wchar_t*)GlobalLock(h);
                         if (t) SetWindowTextW(hLink, t);
                         GlobalUnlock(h); }
                CloseClipboard();
            }
            return 0;
        }
        if (InRect(g_rcDel, pt)) {
            int sel = (int)SendMessageW(hServers, CB_GETCURSEL, 0, 0);
            if (sel >= 0 && sel < (int)g_servers.size()) {
                g_servers.erase(g_servers.begin() + sel);
                SaveServers(); ReloadCombo();
            }
            return 0;
        }
        if (InRect(g_rcTog1, pt)) { g_sysProxy = !g_sysProxy; SaveSettings();
             if (g_state == ST_ON) SetSystemProxy(g_sysProxy); InvalidateAll(); return 0; }
        if (InRect(g_rcTog2, pt)) { g_autoStart = !g_autoStart; SaveSettings(); InvalidateAll(); return 0; }
        if (InRect(g_rcLogT, pt)) { ShowLog(!g_logVisible); return 0; }
        // перетаскивание окна за пустое место
        ReleaseCapture();
        SendMessageW(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        return 0;
    }

    case WM_RBUTTONUP: {
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        ClientToScreen(hwnd, &pt);
        HMENU m = CreatePopupMenu();
        AppendMenuW(m, MF_STRING, 3001, L"Открыть");
        AppendMenuW(m, MF_SEPARATOR, 0, NULL);
        AppendMenuW(m, MF_STRING | (g_state == ST_ON ? MF_GRAYED : 0), 3002, L"Подключить");
        AppendMenuW(m, MF_STRING | (g_state == ST_ON ? 0 : MF_GRAYED), 3003, L"Отключить");
        AppendMenuW(m, MF_SEPARATOR, 0, NULL);
        AppendMenuW(m, MF_STRING, 3004, L"Выход");
        int cmd = TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, hwnd, NULL);
        DestroyMenu(m);
        if (cmd == 3001) ShowWindow(hwnd, SW_RESTORE);
        else if (cmd == 3002) DoConnect();
        else if (cmd == 3003) DoDisconnect();
        else if (cmd == 3004) DestroyWindow(hwnd);
        return 0;
    }

    case WM_APP_TRAY: {
        if (lParam == WM_LBUTTONDBLCLK) ShowWindow(hwnd, SW_RESTORE);
        else if (lParam == WM_RBUTTONUP) {
            POINT pt; GetCursorPos(&pt);
            HMENU m = CreatePopupMenu();
            AppendMenuW(m, MF_STRING, 3001, L"Открыть");
            AppendMenuW(m, MF_STRING | (g_state == ST_ON ? MF_GRAYED : 0), 3002, L"Подключить");
            AppendMenuW(m, MF_STRING | (g_state == ST_ON ? 0 : MF_GRAYED), 3003, L"Отключить");
            AppendMenuW(m, MF_SEPARATOR, 0, NULL);
            AppendMenuW(m, MF_STRING, 3004, L"Выход");
            SetForegroundWindow(hwnd);
            int cmd = TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, hwnd, NULL);
            DestroyMenu(m);
            if (cmd == 3001) ShowWindow(hwnd, SW_RESTORE);
            else if (cmd == 3002) DoConnect();
            else if (cmd == 3003) DoDisconnect();
            else if (cmd == 3004) DestroyWindow(hwnd);
        }
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        HDC mem = CreateCompatibleDC(hdc);
        HBITMAP bm = CreateCompatibleBitmap(hdc, CW, g_clientH);
        HBITMAP ob = (HBITMAP)SelectObject(mem, bm);
        Paint(mem);
        BitBlt(hdc, 0, 0, CW, g_clientH, mem, 0, 0, SRCCOPY);
        SelectObject(mem, ob);
        DeleteObject(bm);
        DeleteDC(mem);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_ERASEBKGND:
        return 1;

    case WM_CLOSE:
        ShowWindow(hwnd, SW_HIDE); // в трей
        return 0;

    case WM_QUERYENDSESSION:
        StopXray();
        return TRUE;

    case WM_DESTROY: {
        KillTimer(hwnd, ID_TIMER_ANIM);
        KillTimer(hwnd, ID_TIMER_CHECK);
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        StopXray();
        if (g_hLogThread) { WaitForSingleObject(g_hLogThread, 500); CloseHandle(g_hLogThread); }
        PostQuitMessage(0);
        return 0;
    }
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    InitializeCriticalSection(&g_logCS);
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
    SetProcessDPIAware();

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"OselVPN2";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClassW(&wc);

    g_hwnd = CreateWindowExW(0, L"OselVPN2", L"OselVPN " APP_VER,
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 720 + 16, 486 + 46, NULL, NULL, hInstance, NULL);
    if (!g_hwnd) return 1;
    ShowWindow(g_hwnd, nCmdShow);
    UpdateWindow(g_hwnd);

    MSG msg = {};
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    WSACleanup();
    return 0;
}
